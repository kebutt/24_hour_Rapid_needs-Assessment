HOT — 24-HOUR RNA DEMO v1
Prepared 16 November 2026 for review. Historical Cyclone Idai case, Mozambique.

OPEN THE SITE
Select Observed case to inspect later flood exposure. Select First 24 hours to see the evidence available by the adopted cutoff, 15 March 2019 23:30 UTC. Unknown values are intentionally not zero. All reference geography is labelled; later OSM and flood layers are hidden in the first-day scenario.

SCOPE
The assessment boundary is an analyst-selected area containing clipped portions of Beira, Búzi, Dondo and Nhamatanda, not an official disaster impact boundary. District results cover only those portions. The separate Copernicus change comparison covers its Beira mapping area, not the entire assessment area.

INTERPRETATION
Observed flood is satellite interpretation, not field validation. Population figures are 2015 modelled residents whose pixel centres fall in mapped flooding. Building values count OSM bounding-box centre proxies, not damaged buildings. Road overlaps include paths and do not establish closure or passability. Facility symbols are selected OSM elements; functionality is unknown. Zero selected facility or place-point intersections does not establish no affected services or communities. No synthetic field report feeds the metrics.

CHANGE
Official Copernicus Sentinel-1 interpretations from 19 March 16:14 UTC and 20 March 03:08 UTC are compared only within common coverage. Version 2 was released 9 April 2019. Both observations are after landfall. This is a retrospective mapped-extent comparison; classification and viewing differences may contribute. It is not pre/post-cyclone change detection or first-24-hour information.

FILES
data/: browser display geometry, simplified for performance. Do not recompute precise statistics from these files.
analytical_change/: full-resolution comparison geometry and metadata; areas calculated in EPSG:32736.
downloads/: data and evidence registers, district summaries, and an empty field-verification template.
processing/: scripts documenting the analysis. Original source archives are linked in metadata.

ATTRIBUTION
UNITAR-UNOSAT / Copernicus ESA Sentinel-1: associated map CC BY-NC 3.0; noncommercial demonstration.
WorldPop, University of Southampton: CC BY 4.0.
OpenStreetMap contributors: ODbL 1.0, https://www.openstreetmap.org/copyright
INE/OCHA COD-AB via HDX: CC BY-IGO, current reference edition.
Natural Earth: public domain contextual outlines.
Copernicus EMS: © European Union.
Mixed-source data retain their individual terms; no single licence is asserted for the archive.

REVIEW
This prototype does not collect or send field reports, publish to uMap, launch Tasking Manager projects, or replace government approval. Its outputs demonstrate the analysis, briefing and verification handoff. Confirm indicators, owners, minimum first-day evidence and sign-off with INGD/CENOE and UNICEF before an operational pilot.
