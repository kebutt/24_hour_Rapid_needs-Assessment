/* Deterministic screening on supplied WGS84 geometries. No damage inference. */
(function(root){
const fc=f=>({type:'FeatureCollection',features:f});
function polygon(g){const p=g.features.filter(f=>f.geometry&&['Polygon','MultiPolygon'].includes(f.geometry.type));if(!p.length)throw Error('A polygon boundary / hazard footprint is required.');for(const f of p)if(!turf.booleanValid(f))throw Error('Repair invalid polygon geometry before analysis.');return p.length===1?p[0]:turf.union(fc(p));}
function insideLength(f,poly){let result=0;turf.flattenEach(f,line=>{if(line.geometry.type!=='LineString')return;const cut=turf.lineSplit(line,poly);for(const seg of cut.features.length?cut.features:[line]){const km=turf.length(seg);if(km>0&&turf.booleanPointInPolygon(turf.along(seg,km/2),poly))result+=km;}});return result;}
function categories(f){const p=f.properties.tags||f.properties,a=p.amenity;return {buildings:!!p.building&&p.building!=='no',roads:!!p.highway,health:['hospital','clinic','doctors','health_post'].includes(a)||(!!p.healthcare&&p.healthcare!=='no'),schools:['school','kindergarten','college','university'].includes(a),water:['drinking_water','water_point'].includes(a)||['water_well','water_tap','water_works'].includes(p.man_made)||p.emergency==='water_tank',shelters:['shelter','social_facility'].includes(a)||p.social_facility==='shelter'};}
function analyze(input){
 const aoi=polygon(input.aoi),hazard=polygon(input.hazard),foot=turf.intersect(fc([aoi,hazard]));
 const unique=new Map(),skipped=[];for(const [i,f] of input.osm.features.entries()){if(!f.geometry){skipped.push(i);continue;}const id=f.id||f.properties?.['@id']||f.properties?.id||(f.properties?.osm_type&&f.properties?.osm_id?f.properties.osm_type+'/'+f.properties.osm_id:null);if(!id)throw Error('Every OSM feature needs its unique type/id (for example way/123).');if(!unique.has(String(id)))unique.set(String(id),f);}
 const totals={buildings:0,roads:0,health:0,schools:0,water:0,shelters:0},exposed={...totals};let roadKm=0,baselineRoadKm=0,facilityCount=0,baselineFacilities=0;const facilities=[];
 for(const [id,f] of unique){if(!turf.booleanIntersects(f,aoi))continue;const c=categories(f),hit=!!foot&&turf.booleanIntersects(f,foot);for(const k of Object.keys(totals))if(c[k]){totals[k]++;if(hit)exposed[k]++;}
 if(c.roads){baselineRoadKm+=insideLength(f,aoi);if(foot)roadKm+=insideLength(f,foot);}
 if(c.health||c.schools||c.water||c.shelters){baselineFacilities++;if(hit)facilityCount++;const p=f.properties.tags||f.properties;const point=f.geometry.type==='Point'?structuredClone(f):turf.pointOnFeature(f);point.properties={id,name:p.name||'Unnamed mapped service',type:c.health?'Health':c.schools?'Education':c.water?'Water':'Shelter / social facility',status:'Unknown',exposed:hit};facilities.push(point);}
 }
 const warnings=['Counts are mapped OSM elements, not confirmed damaged buildings, unique physical facilities or people.','Repeated OSM IDs are removed; node/way representations of the same facility may still duplicate a physical asset.','OSM coverage is incomplete; no matches does not prove that no assets or needs exist.'];if(skipped.length)warnings.push(skipped.length+' OSM elements lack geometry and were skipped.');
 return {metrics:{hazardAreaKm2:foot?turf.area(foot)/1e6:0,peopleExposed:null,roadsOverlapKm:roadKm,facilitiesExposed:facilityCount},exposure:{totals,exposed,baselineRoadKm,baselineFacilities,facilityCount,osmElements:unique.size,skippedGeometries:skipped.length},footprint:foot?fc([foot]):fc([]),facilities:fc(facilities),warnings};
}
root.RNAEngine={analyze,polygon,insideLength};if(typeof module!=='undefined')module.exports=root.RNAEngine;
})(typeof globalThis!=='undefined'?globalThis:this);
