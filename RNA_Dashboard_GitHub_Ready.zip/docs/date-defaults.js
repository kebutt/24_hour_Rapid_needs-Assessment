/* Date suggestions never substitute event timing for observation evidence. */
(function(root){
function iso(value){if(typeof value!=='string'||!value.trim())return null;const s=value.trim();if(!/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}/.test(s))return null;const z=/Z$|[+-]\d{2}:\d{2}$/.test(s)?s:s+'Z';const n=Date.parse(z);return Number.isFinite(n)?new Date(n).toISOString():null;}
function input(value){const v=iso(value);return v?v.slice(0,23).replace(/\.000$/,''):'';}
function cutoff(trigger){const v=iso(trigger);return v?new Date(Date.parse(v)+86400000).toISOString():null;}
function snapshot(trigger,stage,now=Date.now()){const end=cutoff(trigger);return new Date(Math.floor((stage==='first24'&&end?Math.min(Date.parse(end),now):now)/1000)*1000).toISOString();}
function defaults(d,stage='first24',now=Date.now()){
 const saved=iso(d.event?.onsetISO),suggested=iso(d.catalogue?.fromdate),trigger=saved||suggested;
 if(!saved&&trigger&&Date.parse(trigger)>now)stage='forecast';
 const evidence=d.stages?.[stage]?.evidence||{},storedSnapshot=iso(d.analysisInputs?.osmSnapshot);
 return {stage,trigger,triggerSuggested:!saved&&!!suggested,triggerOrigin:saved?'Saved event trigger':suggested?'Suggested from GDACS event start; confirm local impact / landfall':'Enter the agreed local impact or expected impact time',cutoff:cutoff(trigger),observation:iso(evidence.observationISO),available:iso(evidence.availableISO),source:evidence.source||'',snapshot:storedSnapshot||snapshot(trigger,stage,now),snapshotAutomatic:!storedSnapshot,snapshotOrigin:storedSnapshot?'Restored from the saved OSM input':stage==='first24'?'Suggested snapshot: first-day cutoff, or now if earlier':'Suggested snapshot: current time; change for a historical baseline'};
}
root.RNADates={iso,input,cutoff,snapshot,defaults};if(typeof module!=='undefined')module.exports=root.RNADates;
})(typeof globalThis!=='undefined'?globalThis:this);
