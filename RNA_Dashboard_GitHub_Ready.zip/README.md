# Rapid Needs Assessment — GitHub Pages package

This copy includes the guided inputs and date defaults from dashboard commit 0ab17273a7236534793ed522d03408650b5a8fad. It is ready to upload to a GitHub repository. No Node build or application server is required.

## Publish using GitHub's website

1. Extract this ZIP on your computer. Do not upload the ZIP itself as the website.
2. Create a repository, for example `rna-dashboard`. For a public demo on GitHub Free, choose Public. Review the data first: normal GitHub Pages hosting makes the website and bundled data public, and the existing ChatGPT sign-in gate is not included.
3. Use Add file → Upload files. Upload the `docs` folder and this README to the repository root. Preserve all subfolders. Commit to `main`.
4. Confirm the repository contains `docs/index.html`, `docs/app.js`, `docs/data/`, `docs/vendor/` and `docs/downloads/`. Avoid an extra enclosing folder.
5. Open Settings → Pages. Under Build and deployment, choose Deploy from a branch. Select `main` and `/docs`, then Save.
6. Wait for the Pages deployment to succeed. Open the exact website URL shown in Settings → Pages. Typical project URL: https://YOUR-USERNAME.github.io/rna-dashboard/
7. Verify the sample map, event switcher, Prepare / run assessment date guidance, event import/export, and a small exposure calculation. Check GDACS access from the published domain. OSM service availability is not guaranteed.

If the bundled hidden `docs/.nojekyll` file was omitted during upload, create it using Add file → Create new file. The file tells GitHub to serve the prepared static assets directly.

## What transfers

Interactive Leaflet maps, the historical Idai sample, event import/export, guided dates, client-side spatial screening, templates and documentation are included. The map and worker paths are relative, suitable for a GitHub project subdirectory.

## What does not change

Imported event data stays only in the browser tab. Export it to retain it. There is no shared database, automatic background monitoring, imagery processing service or server-side population analysis. GitHub Pages does not add these capabilities. Live GDACS and Overpass requests remain subject to their availability and cross-origin access policies. Overpass verification previously returned HTTP 406; local OSM GeoJSON import remains available.

The previous private host's authentication does not transfer. Do not add confidential field reports, names of vulnerable people, private contact lists, credentials or API keys to a public repository or site. Keep source and vendor attribution and the bundled licence files.

## Updating later

Edit files in `docs/` and commit to `main`. GitHub Pages republishes the selected folder. Changes made to the earlier ChatGPT-hosted version do not automatically synchronise to this separate repository.

## Validation status

The source calculations, date logic and local file paths were checked. The package has not yet been deployed to or browser-tested on GitHub Pages. The latest input screens still need visual verification because the prior preview environment was blocked.

## Official instructions

- https://docs.github.com/en/pages/getting-started-with-github-pages/configuring-a-publishing-source-for-your-github-pages-site
- https://docs.github.com/en/pages/getting-started-with-github-pages/what-is-github-pages
