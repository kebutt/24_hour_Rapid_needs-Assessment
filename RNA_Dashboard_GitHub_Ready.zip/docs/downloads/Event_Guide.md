# First-time input guidance and date defaults

After selecting a GDACS event, Prepare / run assessment suggests its catalogue start as a trigger. Confirm or correct it to the agreed local impact / landfall time; a storm’s origin is often earlier. Saved event triggers take precedence. A future catalogue start suggests the Forecast view. The first-day cutoff always updates to trigger + 24 hours.

For first-day analysis, the suggested OSM fetch snapshot is the earlier of cutoff and current time. Other views suggest current time unless a saved extract supplies its own date. Manually entered snapshots are preserved when the trigger changes. A loaded extract’s known snapshot is read-only; replace the extract to change it.

Observation and publication dates are never copied from event dates. Saved evidence restores them. Selecting a GDACS hazard polygon fills its polygon date and archive revision time, with explicit source notes; a later revision remains ineligible for first-day replay. Missing timestamps remain blank.

Uploading a new hazard file clears old dates and source text unless its top-level `metadata` supplies `observationISO`, `availableISO` and `source`. Uploading OSM clears the proposed fetch date unless the file supplies `metadata.osmSnapshot`. These are timezone-aware ISO strings, for example `2019-03-15T03:08:00Z`. Check metadata against the original source; a file’s assertions are not independently verified. Never use the file download date as acquisition, publication or OSM snapshot time.

Every editable section has short field guidance. The setup shows the calculated cutoff, outstanding inputs, timing conflicts and whether trigger confirmation is needed. All form times are UTC. Source timestamps with explicit offsets are converted to UTC; manual local times are not automatically converted.

---

# Guided workflow added in this version

1. **Find event** searches GDACS by dates, hazard and optional ISO3 country. **Current alerts** searches the last 30 days; it is not a guarantee that an event is currently active or will affect your area. Select the event and confirm the local trigger / expected impact time. An event origin date is not automatically landfall.
2. **Prepare / run assessment** separates Forecast, First 24 hours and Later / retrospective views. The system checks timing and rejects later source revisions in a first-day replay.
3. Upload AOI and hazard GeoJSON, or choose a GDACS polygon and explicitly assign its role. Record its threshold and interpretation. A point, track or forecast cone is not sufficient evidence of experienced hazard intensity. Never treat GDACS catalogue metadata as a verified impact footprint.
4. Import an OSM GeoJSON export with original unique OSM IDs and tags, or fetch a small AOI snapshot from Overpass. Existing saved OSM inputs can be rerun. Confirm the extract covers the whole AOI and all required categories. An imported file's claimed snapshot date needs analyst verification; the software cannot reconstruct its provenance.
5. Calculate exposure and review the resulting map, four indicators, OSM category table, evidence gaps and three suggested next actions. Export the event package to retain inputs, results, dates and methods. Keep only one version of each district geometry in your baseline.

**What is automated:** catalogue search, candidate geometry retrieval, bounded OSM retrieval, AOI/hazard intersection, area, intersecting building/service element counts, clipped road lengths, optional administrative breakdowns from an existing imported package, draft explanatory text and next checks.

**What still needs human input:** local event trigger, appropriate AOI and hazard product/threshold, evidence availability, baseline completeness, validated population overlay, genuine service condition, humanitarian needs, and approval of next actions. Forecasts describe potential exposure before impact. Historical replay requires eligible evidence from the selected cutoff; latest archive revisions are retrospective.

The public OSM request is limited to a 2,500 km² bounding box and 15,000 returned elements. GeoJSON inputs have a 25 MB / 15,000-feature demonstration limit; a calculation stops after 60 seconds. Public services can time out or impose limits. The Overpass verification request returned HTTP 406 in this environment; use imported OSM GeoJSON if the automatic fetch is unavailable. Large operational assessments need prepared regional extracts and a managed processing service. No background monitoring or unattended 24-hour pipeline is running.

The computation uses Turf 7.2.0, geodesic area/length and WGS84 polygon operations. Overlapping hazard polygons are unioned, roads split at the hazard boundary, and interior segments summed. Counts use intersecting OSM elements, deduplicated by OSM ID. Multiple elements can describe one physical asset. Health categories include healthcare-tagged features and hospital/clinic/doctors/health_post; education includes school/kindergarten/college/university; water includes drinking_water/water_point/water_well/water_tap/water_works; shelters include shelter/social_facility. These selections are a screening baseline, not complete sector inventories. Roads include all highway-tagged ways, including paths.

**Data references:** [GDACS API](https://www.gdacs.org/gdacsapi/swagger/index.html), [GDACS quick start](https://www.gdacs.org/Documents/2025/GDACS_API_quickstart_v2.pdf), [Overpass service guidance](https://dev.overpass-api.de/overpass-doc/en/preface/commons.html), [OSM attribution](https://www.openstreetmap.org/copyright), [Turf intersection](https://turfjs.org/docs/api/intersect). GDACS expects acknowledgement. OSM data are under ODbL. API queries send only the selected catalogue filters or AOI bounding box and snapshot time; imported files and calculated results remain in the browser tab.

---

# Reuse the 24-hour assessment dashboard

The same interface accepts different events and countries. Idai is a historical sample. The dashboard supports GDACS event discovery and repeatable OSM exposure screening, plus imported reviewed results. It does not generate satellite hazard footprints, verify humanitarian needs or estimate population from buildings.

## Start another event

1. Select **New event**. Enter a name, country/region, hazard and trigger time in UTC. The cutoff is exactly 24 hours later.
2. Open **Sources & data → Export current event** to save the empty event JSON. Alternatively download the blank template.
3. Add reviewed statistics, sources, priorities and embedded GeoJSON layers using the structure below. Use the Idai sample export as a populated structural example; replace all its evidence and geography.
4. Select **Import data** and choose the prepared JSON. Switch between imported events using the Event selector. Invalid files are rejected without replacing the selected event.
5. Check scope, dates, sources and figures; use district selection and the map, then print or download the briefing CSV.
6. Export each completed event package. Events exist only in the current tab: closing or reloading resets to the sample. Import the exported package to restore it. Imports are processed locally in the browser, not uploaded or shared with other viewers.

## Package structure — schemaVersion: 1

Keep the template's property names. All coordinates must be WGS84 longitude, latitude (EPSG:4326). Layers are embedded GeoJSON FeatureCollections, not paths or URLs. Empty layers use {"type":"FeatureCollection","features":[]}.

| Property | What to supply |
| --- | --- |
| event | Unique id, name, country, hazard, onsetISO, cutoffISO, isDemo and reviewer. ISO times include a timezone; use UTC Z. isDemo remains true for tests/drafts. |
| scope | Plain-language assessment coverage, including any administrative-area clipping. |
| boundaryNote | Who delineated the working area, source, date/time, method and confidence; distinguish it from observed impact. |
| hazardLabel | Label such as Mapped floodwater or Mapped wind footprint. Use the actual evidence type. |
| populationNote | Population dataset, year, method and coverage; explain potential exposure versus confirmed impact. |
| facilityNote | Inventory source/date, completeness, duplication and verification limitations. |
| attribution | Required cartographic source credits; never remove underlying dataset licence credits. |
| stages.first24 | asOf, notice, metrics and optional context array. Include only evidence available at the first-day cutoff, and disclose later reference baselines. |
| stages.forecast | Optional preparedness snapshot, with the same fields; future valid times are forecasts, not observed impact. |
| stages.observed | Optional later snapshot with the same fields. Omit this entire stage if unavailable; its button is then disabled. |
| districts | Array of {id, name, metrics:{first24:{…}, observed:{…}}}. Supply metrics for every included stage; values are for AOI portions, not necessarily whole districts. |
| priorities | Array of {id, scenarioId, districtId, location, finding, evidenceStatus, action, owner, sourceIds, lon, lat}. scenarioId is first24, forecast or observed. districtId and coordinates may be null for general actions. The first three applicable records display, in your priority order. |
| sources | Array with id, title, provider, url, referenceDate, availableDate, evidenceType, limitations. Record publication/release dates separately from acquisition dates. URLs must be http(s). |
| methods | Array of plain-language methodology and quality-assurance notes. |
| layers | GeoJSON layers as below. |
| change | {available:false} until comparable observations and their analysis exist. |

## Indicators

Each metrics object contains four keys. Values are non-negative numbers or **null** for unknown; never enter zero for missing evidence.

- hazardAreaKm2: mapped hazard extent in the assessment area, square kilometres.
- peopleExposed: modelled population intersecting that footprint; not confirmed affected people.
- roadsOverlapKm: length of mapped roads/paths overlapping the footprint.
- facilitiesExposed: count of selected mapped service elements overlapping the footprint; not confirmed damaged facilities.

Keep definition and population vintage consistent within an event. Statistics can be supplied in the event package or calculated through Prepare / run assessment. The browser engine clips the hazard to the AOI, counts intersecting OSM elements and sums clipped road lengths; it leaves population unknown. Changing a map layer without recomputing corresponding totals will create an inconsistent briefing. The importer checks format, coordinate ranges and required fields, but cannot certify sources, spatial calculations, interpretation or operational validity.

An optional stage.context array can hold reported wind speeds or national forecasts: {label,value,scope,note,sourceId}. These appear in Sources & data and in that stage's CSV, separate from assessment-area exposure totals.

## Map layers

| Key | Contents |
| --- | --- |
| aoi | Working assessment boundary polygons. The map and locator derive their position from this layer. |
| context | Optional surrounding land/administrative polygons for the main map and locator. Supply appropriate context for the new country; there is no live basemap download. |
| districts | Polygons with properties.id and properties.name matching the districts records. Merge each district to one multipart feature if needed. |
| first24 | Eligible observed/forecast hazard footprint for the first-day view. Explain evidence type explicitly in labels and notes. Leave empty if unavailable. |
| forecast | Forecast hazard polygon; specify threshold, issuance and valid time. |
| observed | Footprint corresponding to the optional later stage. |
| facilities | Points with properties.name, type, status, districtId and id. Unknown functionality must be labelled Unknown. |
| change_new | Hazard mapped only in the later observation. |
| change_persistent | Hazard mapped in both observations. |
| change_receded | Hazard mapped only in the earlier observation. |
| change_coverage | Common valid observation coverage used for comparison. |

Optional layers can be empty. No event boundary means no implied location: the map opens at a neutral world view. Display geometry may be simplified, but compute results on appropriate full-resolution data first. The package size limit is 25 MB. Events crossing the antimeridian or near the poles may need tailored mapping/projection treatment; this general Web Mercator viewer is not a universal cartographic solution.

## Enable change detection

Prepare comparable extents in a GIS: check sensor/interpretation consistency, acquisition times and quality; clip both dates to common valid observation coverage; compute new, persistent and earlier-only extents. Record uncertainty. Never interpret differences automatically as damage or recovery.

Set change.available to true; provide baselineDate, observationDate, description, newAreaKm2, persistentAreaKm2, recededAreaKm2 and comparisonAreaKm2, plus the four change layers. Include an observed stage. These metrics are for the common comparison area and do not change with district selection. Both dates may be post-event; make that clear. The Idai comparison is retrospective, not evidence available within its first 24 hours.

## Analyst review before release

Confirm trigger and cutoff with the coordination team. Validate geometry, dates and data availability; calculate exposure in an appropriate projected/equal-area CRS; reconcile duplicate facilities and overlaps; document missing coverage and uncertainty. Ensure district metrics and total metrics describe the same scope. Confirm proposed follow-ups and responsible teams. The dashboard does not collect field submissions, fetch imagery, generate hazard footprints or automatically establish need/severity. It can discover GDACS records, load candidate GDACS polygons, fetch bounded OSM extracts and calculate exposure intersections on supplied data.

The four indicators suit spatial exposure screening for floods, cyclones and comparable hazards. Other hazards can use the viewer where these definitions remain meaningful; drought, earthquakes or sector-specific assessments may require additional indicators and analysis. A reusable presentation does not make all hazard methodologies interchangeable.
