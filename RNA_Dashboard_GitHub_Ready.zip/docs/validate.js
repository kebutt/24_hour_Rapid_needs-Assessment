/* Portable RNA event package v1 validation; shared by browser and checks. */
(function(root){
function validate(d){
 const fail=m=>{throw Error(m);},text=(s,n)=>{if(typeof s!=='string'||!s.trim())fail(n+' must be non-empty text');};
 if(!d||d.schemaVersion!==1)fail('Expected schemaVersion 1');
 if(!d.event)fail('Missing event metadata');for(const k of ['id','name','country','hazard'])text(d.event[k],'event.'+k);
 for(const k of ['onsetISO','cutoffISO'])if(d.event[k]!=null&&!Number.isFinite(Date.parse(d.event[k])))fail('Invalid '+k);
 if(d.event.onsetISO&&d.event.cutoffISO&&Date.parse(d.event.cutoffISO)-Date.parse(d.event.onsetISO)!==86400000)fail('First-day cutoff must be exactly 24 hours after the event trigger');
 for(const k of ['scope','boundaryNote','hazardLabel','populationNote','facilityNote','attribution'])text(d[k],k);
 for(const k of ['districts','priorities','sources','methods'])if(!Array.isArray(d[k]))fail(k+' must be an array');
 const metric=m=>{if(!m||typeof m!=='object')fail('Missing metrics object');for(const k of ['hazardAreaKm2','peopleExposed','roadsOverlapKm','facilitiesExposed'])if(m[k]!==null&&(!Number.isFinite(m[k])||m[k]<0))fail(k+' must be a non-negative number or null');};
 if(!d.stages?.first24)fail('Missing first24 stage');for(const [k,s] of Object.entries(d.stages)){if(!['first24','forecast','observed'].includes(k))fail('Unknown stage '+k);text(s.asOf,k+'.asOf');text(s.notice,k+'.notice');metric(s.metrics);if(s.context&&!Array.isArray(s.context))fail('context must be an array');}
 const ids=new Set();for(const x of d.districts){text(x.id,'District ID');text(x.name,'District name');if(ids.has(x.id))fail('Duplicate district ID');ids.add(x.id);if(!x.metrics)fail('Missing district metrics');for(const k of Object.keys(d.stages))metric(x.metrics[k]);}
 for(const p of d.priorities){for(const k of ['id','location','finding','evidenceStatus','action'])text(p[k],'Priority '+k);if(!d.stages[p.scenarioId])fail('Priority references unknown stage');if(p.districtId&&!ids.has(p.districtId))fail('Priority references unknown district');if((p.lat!=null||p.lon!=null)&&(!Number.isFinite(p.lat)||Math.abs(p.lat)>90||!Number.isFinite(p.lon)||Math.abs(p.lon)>180))fail('Invalid priority coordinates');}
 for(const s of d.sources){text(s.title,'Source title');if(s.url&&!/^https?:\/\//i.test(s.url))fail('Source links must use https or http');}
 if(!d.layers||typeof d.layers!=='object')fail('Missing layers');
 const coords=c=>{if(!Array.isArray(c)||!c.length)fail('Invalid geometry coordinates');if(typeof c[0]==='number'){if(c.length<2||!c.every(Number.isFinite)||Math.abs(c[0])>180||Math.abs(c[1])>90)fail('Coordinates must be WGS84 longitude, latitude');}else c.forEach(coords);};
 const geometry=g=>{if(!g)return;if(g.type==='GeometryCollection'){if(!Array.isArray(g.geometries))fail('Invalid geometry collection');g.geometries.forEach(geometry);}else{if(!['Point','MultiPoint','LineString','MultiLineString','Polygon','MultiPolygon'].includes(g.type))fail('Unsupported GeoJSON geometry');coords(g.coordinates);}};
 for(const [name,g] of Object.entries(d.layers)){if(!g||g.type!=='FeatureCollection'||!Array.isArray(g.features))fail(name+' must be an embedded GeoJSON FeatureCollection');if(g.crs)fail('Remove legacy CRS metadata and reproject to WGS84');for(const f of g.features){if(f.type!=='Feature')fail('Invalid GeoJSON feature');geometry(f.geometry);if(!f.properties||typeof f.properties!=='object')fail('Feature properties must be an object');if(name==='districts'&&!ids.has(f.properties.id))fail('District geometry ID has no matching district record');}}
 if(d.change?.available){if(!d.stages.observed)fail('Comparison requires an observed stage');for(const k of ['newAreaKm2','persistentAreaKm2','recededAreaKm2','comparisonAreaKm2'])if(!Number.isFinite(d.change[k])||d.change[k]<0)fail('Invalid comparison metric '+k);for(const k of ['baselineDate','observationDate','description'])text(d.change[k],'change.'+k);for(const k of ['change_new','change_persistent','change_receded','change_coverage'])if(!d.layers[k])fail('Missing comparison layer '+k);if(!d.layers.change_coverage.features.length)fail('Comparison needs common coverage geometry');}
 return true;
}
function validateTiming(t,now=Date.now()){
 const {trigger,obs,available,snapshot,stage,revision}=t;
 if(!['first24','forecast','observed'].includes(stage))throw Error('Invalid assessment stage');
 for(const [k,v] of Object.entries({trigger,obs,available,snapshot}))if(!v||!Number.isFinite(Date.parse(v)))throw Error('Fill in a valid UTC '+k+' time');
 const cutoff=new Date(Date.parse(trigger)+86400000).toISOString();
 if(Date.parse(available)>now||Date.parse(snapshot)>now)throw Error('Publication and OSM snapshot times cannot be in the future.');
 if(stage!=='forecast'&&Date.parse(obs)>now)throw Error('Future observations must use Forecast.');
 if(stage==='first24'){
  if(Date.parse(trigger)>now)throw Error('Impact is in the future. Use Forecast.');
  if([obs,available,snapshot,revision].filter(Boolean).some(v=>Date.parse(v)>Date.parse(cutoff)))throw Error('Evidence is later than the first-day cutoff. Use an eligible snapshot or Later / retrospective.');
  if(Date.parse(obs)<Date.parse(trigger))throw Error('A pre-impact footprint belongs in Forecast.');
 }
 if(revision&&Date.parse(available)<Date.parse(revision))throw Error('Availability cannot predate the loaded GDACS archive revision.');
 if(stage!=='forecast'&&Date.parse(available)<Date.parse(obs))throw Error('An observation cannot be published before acquisition.');
 return {...t,cutoff};
}
root.RNA={validate,validateTiming};if(typeof module!=='undefined')module.exports={validate,validateTiming};
})(typeof globalThis!=='undefined'?globalThis:this);
