/* Reusable event briefing. Data stays in this browser tab; no automatic analysis. */
(() => {
'use strict';
const $=id=>document.getElementById(id), esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const fmt=(n,d=0)=>n===null||n===undefined?'Not yet quantified':Number(n).toLocaleString('en',{maximumFractionDigits:d});
const empty=()=>({type:'FeatureCollection',features:[]});
const date=s=>s?new Date(s).toLocaleString('en-GB',{timeZone:'UTC',dateStyle:'medium',timeStyle:'short'})+' UTC':'Not set';
let D,map,inset,groups={},districtLayers={},mode='first24',focus='all',change=false,template;
const events=new Map();
const area=()=>D.districts.find(x=>x.id===focus), stage=()=>D.stages[mode];
const metrics=()=>area()?area().metrics?.[mode]||{}:stage().metrics;
const has=n=>!!D.layers[n]?.features?.length;
const showToast=t=>{$('toast').textContent=t;$('toast').hidden=false;setTimeout(()=>$('toast').hidden=true,4000);};
const priorities=()=>change?[
 {id:'compare-quality',location:'Review the mapped difference',finding:D.change.description,evidenceStatus:'Mapped difference; verification required',action:'Check observation quality and common coverage before interpreting differences as physical change.'},
 {id:'compare-local',location:'Verify newly mapped areas',finding:`${fmt(D.change.newAreaKm2,1)} km² is mapped only in the later observation.`,evidenceStatus:'Proposed verification',action:'Ask local focal points to confirm current conditions and urgent needs.'},
 {id:'compare-access',location:'Confirm access and service status',finding:'An extent comparison does not establish which routes or services are functioning.',evidenceStatus:'Functionality requires verification',action:'Confirm conditions with responsible teams before directing visits.'}
]:D.priorities.filter(x=>x.scenarioId===mode&&(focus==='all'||!x.districtId||x.districtId===focus)).slice(0,3);
function card(label,value,note,unit=''){return `<article class="metric"><p>${esc(label)}</p><strong class="${/[a-z]/i.test(value)?'word':''}">${esc(value)}${unit&&typeof value==='string'&&!/[a-z]/i.test(value)?`<small>${esc(unit)}</small>`:''}</strong><small>${esc(note)}</small></article>`;}
function render(){
 const early=mode==='first24',forecast=mode==='forecast',s=stage(),m=metrics(),c=D.change;
 $('eventTitle').textContent=D.event.name;document.title=D.event.name+' · Rapid needs assessment';
 document.querySelector('.brand small').textContent=(D.event.country||'EVENT BRIEFING').toUpperCase();
 $('locatorLabel').textContent=D.event.country||'LOCATION';$('reviewer').textContent=D.event.reviewer||'Assessment coordination team';
 $('footerNote').textContent=(D.event.isDemo?'Demonstration / draft. ':'')+'Exposure is not verified damage or need. Unknown does not mean zero. Review before operational use.';
 $('forecast').hidden=!D.stages.forecast;$('forecast').classList.toggle('active',forecast);$('forecast').setAttribute('aria-pressed',forecast);$('early').classList.toggle('active',early);$('later').classList.toggle('active',mode==='observed');$('early').setAttribute('aria-pressed',early);$('later').setAttribute('aria-pressed',mode==='observed');$('later').disabled=!D.stages.observed;
 $('district').disabled=change||!D.districts.length;$('change').disabled=mode!=='observed'||!c?.available;$('change').title=c?.available?'Compare supplied observations within common coverage':'No comparison data supplied for this event';$('change').classList.toggle('on',change);$('change').textContent=change?'Return to extent':'Compare observations';
 $('notice').className='notice'+(early?'':' later');$('notice').textContent=change?c.description:(forecast?'Forecast / preparedness. ':'')+(early?'First-day cutoff: '+date(D.event.cutoffISO)+'. ':'')+s.notice;
 $('metrics').innerHTML=change?card('Later observation only',fmt(c.newAreaKm2,1),'Newly mapped extent; verify','km²')+card('Mapped on both dates',fmt(c.persistentAreaKm2,1),'Within common observation coverage','km²')+card('Earlier observation only',fmt(c.recededAreaKm2,1),'No longer mapped; not proof of recovery','km²')+card('Common comparison coverage',fmt(c.comparisonAreaKm2,0),'Comparison area only','km²'):
 card(D.hazardLabel,fmt(m.hazardAreaKm2,1),'Extent interpretation; not verified damage','km²')+card('People potentially exposed',fmt(m.peopleExposed),D.populationNote)+card('Roads / paths overlapping',fmt(m.roadsOverlapKm,1),'Exposure only; closures require verification','km')+card('Mapped service overlaps',fmt(m.facilitiesExposed),'Incomplete inventory; functionality requires verification');
 $('mapTitle').textContent=change?'How did the mapped extent change?':early?'Where should verification begin?':forecast?'Where could impacts occur?':'Where is potential exposure concentrated?';
 $('mapDate').textContent=change?c.baselineDate+' → '+c.observationDate:s.asOf;
 $('scopeNote').textContent=change?fmt(c.comparisonAreaKm2,1)+' km² common comparison coverage':area()?area().name+' · assessment-area portion':D.scope;
 $('mapMessage').hidden=has('aoi')&&!change&&has(mode);$('mapMessage').textContent=!has('aoi')?'No assessment boundary supplied · import event data':change?'Mapped differences are not verified damage':D.boundaryNote;
 $('facilityControl').hidden=(early&&!s.evidence)||change||!has('facilities');
 $('legend').innerHTML='<strong>MAP KEY</strong>'+(change?'<div><i class="swatch" style="background:#ce6b55"></i>Later observation only</div><div><i class="swatch" style="background:#2c8a9f"></i>Both observations</div><div><i class="swatch" style="background:#c4a33e"></i>Earlier observation only</div>':has(mode)?`<div><i class="swatch" style="background:#2c8a9f"></i>${esc(D.hazardLabel)}</div>`:'')+(has('aoi')?`<div><i class="swatch boundary"></i>${change?'Common observation coverage':'Working assessment boundary'}</div>`:'<div>No event layers supplied</div>')+(!change&&$('facilities').checked?'<div><i class="swatch" style="background:#cb4b4b;border-radius:50%;width:8px;height:8px"></i>Service location</div>':'');
 const ps=priorities();document.querySelector('.aside-title h2').textContent=ps.length===3?'Three priority checks':`${ps.length||'No'} priority check${ps.length===1?'':'s'}`;
 $('priorities').innerHTML=ps.map((p,i)=>`<article class="priority"><div class="priority-top"><span class="number">0${i+1}</span><h3><button data-priority="${i}" ${Number.isFinite(p.lat)&&Number.isFinite(p.lon)?'':'disabled'}>${esc(p.location)}</button></h3></div><span class="status">${esc(p.evidenceStatus)}</span><p>${esc(p.finding)}</p><p class="action">${esc(p.action)}</p>${p.owner?`<p>Lead: ${esc(p.owner)}</p>`:''}</article>`).join('')||'<p class="priority">No reviewed priorities supplied. Agree the first checks with the coordination team.</p>';
 document.querySelectorAll('[data-priority]').forEach(b=>b.onclick=()=>{const p=ps[Number(b.dataset.priority)];map.setView([p.lat,p.lon],11);L.popup().setLatLng([p.lat,p.lon]).setContent(`<strong>${esc(p.location)}</strong><p>${esc(p.action)}</p><small>${esc(p.locationNote||'Proposed follow-up location, not a verified incident.')}</small>`).openOn(map);});
 $('decisionAnswers').hidden=change;if(!change)RNAWorkflow.answers(D,mode,area());updateMap();
}
function geo(name,opt={}){return L.geoJSON(D.layers[name]||empty(),opt);}
function buildMap(){
 if(map)map.remove();if(inset)inset.remove();groups={};districtLayers={};
 map=L.map('map',{preferCanvas:true,zoomSnap:.25,zoomDelta:.5,minZoom:1,maxZoom:17,scrollWheelZoom:false}).setView([0,0],2);
 ['land','flood','boundary','facilities'].forEach((n,i)=>{map.createPane(n);map.getPane(n).style.zIndex=200+i*100;});
 geo('context',{pane:'land',interactive:false,style:{fillColor:'#f2f1e9',fillOpacity:1,color:'#bdcbd0',weight:1}}).addTo(map);
 groups.aoi=geo('aoi',{pane:'boundary',interactive:false,style:{color:'#575768',weight:1.7,dashArray:'6 4',fillOpacity:0}});
 groups.districts=geo('districts',{pane:'boundary',style:{color:'#73808b',weight:1,fillOpacity:.025},onEachFeature:(f,l)=>{const id=f.properties.id;districtLayers[id]=l;l.bindTooltip(esc(f.properties.name),{className:'district-label',direction:'center',permanent:true});l.on('click',()=>{if(change||!D.districts.some(d=>d.id===id))return;focus=id;$('district').value=id;render();fit();l.bindPopup(`<strong>${esc(area().name)}</strong><p>${esc(fmt(metrics().peopleExposed))} potentially exposed people.</p><small>Assessment-area portion only. Exposure is not verified need.</small>`).openPopup();});}});
 for(const n of ['first24','forecast','observed','change_new','change_persistent','change_receded'])groups[n]=geo(n,{pane:'flood',interactive:false,style:{weight:0,fillColor:n==='change_new'?'#ce6b55':n==='change_receded'?'#c4a33e':'#2c8a9f',fillOpacity:.7}});
 groups.change_coverage=geo('change_coverage',{pane:'boundary',interactive:false,style:{color:'#575768',weight:2,dashArray:'6 4',fillOpacity:0}});
 L.control.scale({imperial:false,maxWidth:110}).addTo(map);map.attributionControl.setPrefix(esc(D.attribution));
 inset=L.map('locatorMap',{zoomControl:false,attributionControl:false,scrollWheelZoom:false,dragging:false,doubleClickZoom:false,boxZoom:false,touchZoom:false,keyboard:false}).setView([0,0],1);
 geo('context',{interactive:false,style:{color:'#aabac2',weight:.5,fillColor:'#e5e9e7',fillOpacity:1}}).addTo(inset);
 const b=groups.aoi.getBounds();document.querySelector('.locator').hidden=!b.isValid();if(b.isValid()){L.rectangle(b,{color:'#d73f3f',weight:1.5,fillOpacity:.25}).addTo(inset);inset.setView(b.getCenter(),Math.max(1,map.getBoundsZoom(b)-6));}
}
function updateMap(){
 for(const n of ['aoi','districts','first24','forecast','observed','change_new','change_persistent','change_receded','change_coverage']){const on=n.startsWith('change_')?change:!change&&(n==='aoi'||n==='districts'||n===mode);if(on&&!map.hasLayer(groups[n]))groups[n].addTo(map);else if(!on&&map.hasLayer(groups[n]))map.removeLayer(groups[n]);}
 if(groups.facilities)map.removeLayer(groups.facilities);
 if((mode!=='first24'||stage().evidence)&&!change&&$('facilities').checked){groups.facilities=geo('facilities',{pane:'facilities',filter:f=>focus==='all'||f.properties.districtId===focus,pointToLayer:(f,ll)=>L.circleMarker(ll,{radius:5,color:'#fff',weight:1.5,fillColor:'#cb4b4b',fillOpacity:1}),onEachFeature:(f,l)=>l.bindPopup(`<strong>${esc(f.properties.name)}</strong><p>${esc(f.properties.type)}</p><p>Functionality: ${esc(f.properties.status||'Unknown')}</p><small>${esc(D.facilityNote)}</small>`)}).addTo(map);}
 Object.entries(districtLayers).forEach(([id,l])=>l.setStyle({weight:focus===id?2.5:1,color:focus===id?'#c53b3b':'#73808b'}));
}
function fit(){const b=change?groups.change_coverage.getBounds():focus!=='all'&&districtLayers[focus]?districtLayers[focus].getBounds():groups.aoi.getBounds();if(b.isValid())map.fitBounds(b,{padding:[35,35],animate:false,maxZoom:13});else map.setView([0,0],2,{animate:false});}
function sources(){
 $('boundarySource').textContent=D.boundaryNote;$('legacyEvidence').hidden=D.event.id!=='idai-2019';
 $('methods').innerHTML=D.methods.map(t=>`<p>${esc(t)}</p>`).join('');
 const context=Object.values(D.stages).flatMap(s=>s.context||[]);
 $('sourceList').innerHTML=(context.length?'<section class="evidence-context"><h3>Event context · separate from area totals</h3>'+context.map(c=>`<p><strong>${esc(c.label)}: ${esc(c.value)}</strong><br>${esc(c.scope)}<br>${esc(c.note)}</p>`).join('')+'</section>':'')+D.sources.map(s=>`<article class="source"><h3>${s.url?`<a href="${esc(s.url)}" target="_blank" rel="noopener noreferrer">${esc(s.title)} ↗</a>`:esc(s.title)}</h3><span class="type">${esc(s.evidenceType)}</span><p><strong>${esc(s.provider)}</strong> · ${esc(s.referenceDate)}</p><p>Availability: ${esc(s.availableDate)}</p><p>${esc(s.limitations)}</p></article>`).join('');
}
function download(content,name,type){const url=URL.createObjectURL(new Blob([content],{type}));const a=document.createElement('a');a.href=url;a.download=name;a.click();setTimeout(()=>URL.revokeObjectURL(url),1000);}
const filename=()=>D.event.name.replace(/[^a-z0-9_-]/gi,'_');
function csv(){
 const rows=[['event','country','view','scope','as_of','measure','value','unit','evidence_status','next_action']];
 const row=(measure,value,unit,status,action='')=>rows.push([D.event.name,D.event.country,change?'comparison':mode,change?'Common comparison coverage':area()?.name||D.scope,change?D.change.baselineDate+' → '+D.change.observationDate:stage().asOf,measure,value,unit,status,action]);
 for(const [k,u] of change?[['newAreaKm2','km2'],['persistentAreaKm2','km2'],['recededAreaKm2','km2'],['comparisonAreaKm2','km2']]:[['hazardAreaKm2','km2'],['peopleExposed','modelled people'],['roadsOverlapKm','km'],['facilitiesExposed','mapped elements']]){const v=change?D.change[k]:metrics()[k];row(k,v,u,v==null?'Unknown':change?'Mapped difference; requires verification':'Potential exposure; not verified impact');}
 if(!change){const x=area()?area().exposure?.[mode]:stage().exposure;if(x)for(const k of ['buildings','health','schools','water','shelters']){row(k+'_baseline',x.totals[k],'OSM elements','Mapped inventory; may be incomplete');row(k+'_intersecting',x.exposed[k],'OSM elements','Potential exposure; not verified damage');}for(const c of stage().context||[])row(c.label,c.value,'',c.scope+'; '+c.note);}
 priorities().forEach(p=>row(p.finding,'','',p.evidenceStatus,p.action));
 const safe=x=>{const s=String(x??'');return /^[=+@-]/.test(s)?"'"+s:s;};
 download('\ufeff'+rows.map(r=>r.map(x=>'"'+safe(x).replace(/"/g,'""')+'"').join(',')).join('\r\n'),filename()+'_'+mode+(change?'_change':'')+'_brief.csv','text/csv;charset=utf-8');
}
function activate(data,key){
 D=data;mode='first24';focus='all';change=false;$('facilities').checked=false;
 $('district').innerHTML='<option value="all">All assessment areas</option>'+D.districts.map(d=>`<option value="${esc(d.id)}">${esc(d.name)}</option>`).join('');
 $('eventSelect').innerHTML=[...events].map(([id,e])=>`<option value="${esc(id)}">${esc(e.event.name)}${id==='sample'?' · sample':''}</option>`).join('');$('eventSelect').value=key;
 buildMap();sources();render();fit();$('eventStatus').className='';$('eventStatus').textContent=key==='sample'?'Historical sample · replace with your event data.':'Session only · export this event to retain it.';
}
function register(data){RNA.validate(data);const previous=D,previousKey=$('eventSelect').value,key='event-'+crypto.randomUUID();events.set(key,data);try{activate(data,key);}catch(e){events.delete(key);activate(previous,previousKey);throw e;}return key;}
async function init(){
 try{const [sample,t]=await Promise.all(['data/idai-event.json','downloads/Event_Template.json'].map(async p=>{const r=await fetch(p);if(!r.ok)throw Error('Event package unavailable');return r.json();}));template=t;RNA.validate(sample);events.set('sample',sample);activate(sample,'sample');['eventSelect','fit','print','download'].forEach(id=>$(id).disabled=false);
 $('forecast').onclick=()=>setMode('forecast');$('early').onclick=()=>setMode('first24');$('later').onclick=()=>setMode('observed');$('eventSelect').onchange=e=>activate(events.get(e.target.value),e.target.value);
 $('district').onchange=e=>{focus=e.target.value;map.closePopup();render();fit();};$('fit').onclick=fit;$('change').onclick=()=>{change=!change;focus='all';$('district').value='all';$('facilities').checked=false;map.closePopup();render();fit();};$('facilities').onchange=render;$('download').onclick=csv;$('print').onclick=()=>window.print();
 $('exportEvent').onclick=()=>{download(JSON.stringify(D,null,2),filename()+'_event.json','application/json');showToast('Event package exported, including supplied map layers.');};
 $('importEvent').onclick=()=>$('eventFile').click();$('eventFile').onchange=async e=>{const f=e.target.files[0];if(!f)return;try{if(f.size>25*1024*1024)throw Error('File is larger than 25 MB. Simplify display geometries before importing.');const d=JSON.parse(await f.text());register(d);showToast('Event imported. Check sources and figures before use.');}catch(err){$('eventStatus').className='error';$('eventStatus').textContent='Import rejected: '+err.message+' Current event retained.';}finally{e.target.value='';}};
 $('newEvent').onclick=()=>$('newDialog').showModal();$('newForm').onsubmit=e=>{e.preventDefault();const d=structuredClone(template);d.event.name=$('newName').value.trim();d.event.country=$('newCountry').value.trim();d.event.hazard=$('newHazard').value;d.event.id='event-'+crypto.randomUUID();d.event.onsetISO=new Date($('newOnset').value+'Z').toISOString();d.event.cutoffISO=new Date(Date.parse(d.event.onsetISO)+86400000).toISOString();d.stages.first24.asOf='Cutoff: '+date(d.event.cutoffISO);register(d);$('newDialog').close();showToast('Empty event created. Export it to add reviewed data.');};
 RNAWorkflow.init({data:()=>D,mode:()=>mode,template:()=>structuredClone(template),register,save:(d,m)=>{register(d);setMode(m);}});
 for(const name of ['beforeprint','afterprint'])window.addEventListener(name,()=>{map.invalidateSize({animate:false});fit();inset.invalidateSize({animate:false});});
 }catch(e){$('notice').textContent='Could not load the event package: '+e.message;console.error(e);}
}
function setMode(next){if(!D.stages[next])return;mode=next;change=false;focus='all';$('district').value='all';$('facilities').checked=false;map.closePopup();render();fit();}
for(const [b,d] of [['help','helpDialog'],['sources','sourceDialog']])$(b).onclick=()=>$(d).showModal();document.querySelectorAll('dialog .close').forEach(b=>b.onclick=()=>b.closest('dialog').close());
init();
})();
